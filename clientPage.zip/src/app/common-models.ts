export class CommonModels {
}

export interface Clients {
    username: string;
    fname: string;
    lname: string;
  }
  