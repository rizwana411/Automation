import { CommonModels } from './common-models';

describe('CommonModels', () => {
  it('should create an instance', () => {
    expect(new CommonModels()).toBeTruthy();
  });
});
